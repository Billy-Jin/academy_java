package refactoring.ex03.after;

public class Main {
    public static void main(String[] args) {
        Banner hello = new Banner("Hello, World!");
        hello.print(3);
    }
}
